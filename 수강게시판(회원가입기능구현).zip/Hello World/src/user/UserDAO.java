package user;

import java.sql.Connection;
import java.sql.PreparedStatement;

import util.DatabaseUtil;

public class UserDAO {
	//데이터와 연동 되서 기록하고 역으로 데이터를 가져오는 전반적인 역할을 한다.
	//데이터 접근 객체 
	
	//회원가입을 하는 기능 구현.
	public int join(String userID, String userPassword) {
		String SQL = "insert into user values(?,?)";
		try {
			Connection conn = DatabaseUtil.getConnection();
			//물음표에 데이터를 넣을 수 있게한다.
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, userID);
			pstmt.setString(2, userPassword);
			return pstmt.executeUpdate(); //쿼리문 실행 된 값을 리턴한다. 요청한 2개의 값이 반환됨으로 2가 반환된다.
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //오류가 발생한 경우 -1을 리턴해준다.
	}

}
